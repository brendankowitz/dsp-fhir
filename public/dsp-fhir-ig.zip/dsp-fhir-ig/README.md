# DSP-FHIR Implementation Guide (draft)

**Version:** 0.1.0-draft
**Canonical:** https://dsp-fhir.org/ImplementationGuide/dsp-fhir
**FHIR version:** R4 (4.0.1) with R5 cross-version extensions

This package is a **draft** IG source tree generated from the companion site at
<https://brendankowitz.github.io/dsp-fhir/>. It describes how Microsoft's
**Dragon Standard Payload (DSP) 1.0** maps onto HL7 FHIR so DSP data becomes
first-class FHIR content — with `$graphql` as the preferred read contract.

> **Status:** draft / exploratory. Not an HL7 ballot artifact. Not affiliated with
> Microsoft or Nuance. Provided for evaluation and discussion.

## Contents

```
sushi-config.yaml           # FSH publisher config
ig.ini                      # IG Publisher entry point
input/
  fsh/                      # FSH sources (profiles, extensions, logical models, VS/CS)
  resources/                # Hand-authored JSON (CapabilityStatement, OperationDefinition)
  maps/                     # FHIR Mapping Language (FML) skeletons — DSP <-> FHIR
  pagecontent/              # Narrative pages (md)
  examples/                 # Example Bundles + canonical $graphql query
```

## Build locally

```bash
npm install -g fsh-sushi
sushi .

# Download: https://github.com/HL7/fhir-ig-publisher/releases/latest
java -jar publisher.jar -ig ig.ini
```

## Executable mapping (optional)

FML sources in `input/maps/dsp-to-fhir/` and `input/maps/fhir-to-dsp/` are
skeletons that demonstrate both transform directions against the DSP logical
models and profiled FHIR resources. Compile with sushi or the HL7 FHIR Mapping
Language compiler, then execute via `$transform` on a matchbox / HAPI server.
See `input/pagecontent/fml-strategy.md`.

## The normative four

1. **R1** — Transcript turn-index stability within `DocumentReference.meta.versionId`.
2. **R2** — Recording content bound to issuing server's `Binary` endpoint.
3. **R3** — `payload-version` negotiation advertised in `CapabilityStatement`.
4. **R4** — `Provenance` per ingest, targeting all touched resources.

See `input/pagecontent/normative-rules.md`.

## License

Draft under CC0. FHIR artifacts subject to HL7 license terms. "Dragon",
"Dragon Copilot", and "DSP" are Microsoft/Nuance trademarks; this IG is not
endorsed by either.

# DSP-FHIR resource profiles

All resource profile source definitions are available in
`input/fsh/profiles.fsh`. SUSHI expands these FSH definitions into FHIR
`StructureDefinition` resources when the IG is built.

| Profile | Base resource | Notes |
|---|---|---|
| `DspPatient` | `Patient` | DSP patient identity with MRN support |
| `DspPractitioner` | `Practitioner` | DSP practitioner identity with NPI support |
| `DspEncounter` | `Encounter` | Encounter/session context |
| `DspComposition` | `Composition` | Structured note with DSP document sections |
| `DspDocumentReferenceTranscript` | `DocumentReference` | Transcript JSON attachment |
| `DspCondition` | `Condition` | DSP condition/problem/diagnosis |
| `DspMedicationRequest` | `MedicationRequest` | Medication order |
| `DspServiceRequestLab` | `ServiceRequest` | Lab order |
| `DspServiceRequestImaging` | `ServiceRequest` | Imaging order |
| `DspServiceRequestProcedure` | `ServiceRequest` | Procedure order |
| `DspServiceRequestReferral` | `ServiceRequest` | Referral order |
| `DspServiceRequestFollowUp` | `ServiceRequest` | Follow-up order |
| `DspNutritionOrder` | `NutritionOrder` | Dietary order |
| `DspImmunizationRecommendation` | `ImmunizationRecommendation` | Immunization intent |
| `DspImmunization` | `Immunization` | Administered immunization |
| `DspDeviceRequest` | `DeviceRequest` | Device order |
| `DspServiceRequestTherapy` | `ServiceRequest` | Therapy order |
| `DspCarePlan` | `CarePlan` | Activity aggregator |
| `DspServiceRequestStudy` | `ServiceRequest` | Diagnostic study order |
| `DspResearchSubject` | `ResearchSubject` | Research enrollment |
| `DspProvenance` | `Provenance` | Per-ingest provenance |
| `DspMediaRecording` | `Media` | Audio/video recording |

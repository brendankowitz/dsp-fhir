// DSP 1.0 logical models. These describe the DSP JSON shape as FHIR
// StructureDefinitions (kind = logical), enabling $validate on incoming DSP
// payloads and serving as the source side for FML maps.

Logical: DspPayload
Id: DspPayload
Title: "DSP payload envelope (logical)"
Description: "Root DSP 1.0 payload delivered to partners. Mirrors Microsoft's Dragon Standard Payload JSON envelope."
* ^url = "https://dsp-fhir.org/StructureDefinition/DspPayload"
* payload_version 1..1 BackboneElement "Payload version" "Structured version object (major/minor/revision/quality/metadata)."
* payload_version.major 1..1 integer "Major"
* payload_version.minor 1..1 integer "Minor"
* payload_version.revision 0..1 integer "Revision"
* payload_version.quality 0..1 code "Quality" "complete | partial | unavailable | pending | error"
* payload_version.metadata 0..* BackboneElement "Free-form KV metadata"
* payload_version.metadata.key 1..1 string "Key"
* payload_version.metadata.value 1..1 string "Value"
* context 1..1 DspContext "Encounter / session context"
* transcript 0..1 DspTranscript "Transcript"
* recording 0..* DspRecording "Audio/video recordings"
* resources 0..* DspResource "Clinical resources"

Logical: DspContext
Id: DspContext
Title: "DSP context (logical)"
* ^url = "https://dsp-fhir.org/StructureDefinition/DspContext"
* patient 1..1 BackboneElement "Patient identity"
* patient.mrn 0..1 string "Medical record number"
* patient.name 0..1 string "Display name"
* patient.gender 0..1 code
* patient.birth_date 0..1 date
* encounter 1..1 BackboneElement
* encounter.start 0..1 dateTime
* encounter.end 0..1 dateTime
* encounter.timezone 0..1 string "IANA timezone"
* encounter.locale 0..1 code
* encounter.class 0..1 code
* participants 0..* BackboneElement "Participants (clinicians, etc.)"
* participants.role 1..1 code "clinician | patient | other"
* participants.name 0..1 string
* participants.npi 0..1 string
* external_callback_url 0..1 url

Logical: DspTranscript
Id: DspTranscript
Title: "DSP transcript (logical)"
* ^url = "https://dsp-fhir.org/StructureDefinition/DspTranscript"
* turns 1..* BackboneElement "Speaker-turned utterances. Turn indices are immutable within a transcript version (R1)."
* turns.index 1..1 integer
* turns.speaker 0..1 string
* turns.speaker_role 0..1 code "clinician | patient | other"
* turns.text 1..1 string
* turns.start_offset_ms 0..1 integer
* turns.end_offset_ms 0..1 integer
* speaker_count 0..1 positiveInt

Logical: DspRecording
Id: DspRecording
Title: "DSP recording (logical)"
* ^url = "https://dsp-fhir.org/StructureDefinition/DspRecording"
* source 1..1 code "DAXAPP | DAXKIT.haiku | DAXKIT.teams | PMM"
* content_type 1..1 code "MIME type"
* url 1..1 url "Access URL (signed)"
* start 0..1 dateTime
* duration_ms 0..1 integer

Logical: DspResource
Id: DspResource
Title: "DSP clinical resource (logical)"
Description: "Common envelope for all DSP clinical resources. Narrowed by content_type."
* ^url = "https://dsp-fhir.org/StructureDefinition/DspResource"
* id 1..1 string
* content_type 1..1 code "document_section | condition | order.{type}"
* source 0..1 code "dragon_copilot | ehr_integration | extension"
* confidence 0..1 decimal
* transcript_turn_refs 0..* integer
* spoken_forms 0..* string
* payload 1..1 BackboneElement "Type-specific payload; see per-content_type logical models."

Logical: DspConditionResource
Id: DspConditionResource
Parent: DspResource
Title: "DSP condition resource (logical)"
* ^url = "https://dsp-fhir.org/StructureDefinition/DspConditionResource"
* payload.code 0..1 string "Normalized code"
* payload.code_system 0..1 uri
* payload.display 1..1 string
* payload.assertion 1..1 code "asserted | denied | unknown | suspected | history"
* payload.concept_id 0..1 string "Dragon internal concept id"
* payload.onset_text 0..1 string

Logical: DspOrderMedicationResource
Id: DspOrderMedicationResource
Parent: DspResource
Title: "DSP medication order (logical)"
* ^url = "https://dsp-fhir.org/StructureDefinition/DspOrderMedicationResource"
* payload.drug 1..1 string "Free text drug name"
* payload.rxnorm_code 0..1 string
* payload.rendered_dosage_instruction 0..1 string "Full sig as spoken/rendered"
* payload.dose_quantity 0..1 string
* payload.route 0..1 string
* payload.frequency 0..1 string
* payload.prn 0..1 boolean

Logical: DspOrderImagingResource
Id: DspOrderImagingResource
Parent: DspResource
Title: "DSP imaging order (logical)"
* ^url = "https://dsp-fhir.org/StructureDefinition/DspOrderImagingResource"
* payload.modality 1..1 string
* payload.body_site 0..1 string
* payload.laterality 0..1 code
* payload.contrast 0..1 code
* payload.views 0..* string

Logical: DspOrderLabResource
Id: DspOrderLabResource
Parent: DspResource
Title: "DSP lab order (logical)"
* ^url = "https://dsp-fhir.org/StructureDefinition/DspOrderLabResource"
* payload.test 1..1 string
* payload.loinc 0..1 string
* payload.abbreviation 0..1 string

Logical: DspOrderFollowUpResource
Id: DspOrderFollowUpResource
Parent: DspResource
Title: "DSP follow-up order (logical)"
* ^url = "https://dsp-fhir.org/StructureDefinition/DspOrderFollowUpResource"
* payload.return_in_value 0..1 integer
* payload.return_in_unit 0..1 code "d | wk | mo | yr"
* payload.approximation 0..1 boolean
* payload.reason 0..1 string
* payload.prn 0..1 boolean

Logical: DspDocumentSectionResource
Id: DspDocumentSectionResource
Parent: DspResource
Title: "DSP document section (logical)"
* ^url = "https://dsp-fhir.org/StructureDefinition/DspDocumentSectionResource"
* payload.section_type 1..1 string "LOINC or DSP-defined section code"
* payload.title 0..1 string
* payload.text 1..1 string "Narrative (markdown or plain)"

// Patient / Practitioner / Encounter
Profile: DspPatient
Parent: USCorePatientProfile
Id: DspPatient
Title: "DSP Patient"
* identifier 1..*

Profile: DspPractitioner
Parent: USCorePractitionerProfile
Id: DspPractitioner
Title: "DSP Practitioner"
* identifier contains npi 0..1
* identifier[npi].system = "http://hl7.org/fhir/sid/us-npi"

Profile: DspEncounter
Parent: USCoreEncounterProfile
Id: DspEncounter
Title: "DSP Encounter"
* extension contains
    DspPayloadVersion named payloadVersion 0..1 and
    DspExternalCallbackUrl named callbackUrl 0..1 and
    DspRecordingLocale named locale 0..1 and
    DspTimezone named tz 0..1

// Composition / DocumentReference
Profile: DspComposition
Parent: Composition
Id: DspComposition
Title: "DSP Composition"
* type 1..1
* subject only Reference(DspPatient)
* encounter only Reference(DspEncounter)
* section.code from DspDocumentSection (extensible)
* section.extension contains DspSpokenForms named spokenForms 0..*

Profile: DspDocumentReferenceTranscript
Parent: DocumentReference
Id: DspDocumentReferenceTranscript
Title: "DSP transcript DocumentReference"
* content 1..*
* content.attachment.contentType = "application/json"
* extension contains DspSpeakerCount named speakers 0..1

// Condition
Profile: DspCondition
Parent: USCoreConditionProblemsHealthConcernsProfile
Id: DspCondition
Title: "DSP Condition"
* extension contains
    DspAssertionCategory named assertion 0..1 and
    DspConfidenceScore named confidence 0..1 and
    DspTranscriptTurnRefs named turnRefs 0..1 and
    DspSpokenForms named spokenForms 0..* and
    DspResourceSource named source 0..1
* code.extension contains DspConceptId named conceptId 0..1

// Orders
Profile: DspMedicationRequest
Parent: USCoreMedicationRequestProfile
Id: DspMedicationRequest
Title: "DSP MedicationRequest"
* extension contains
    DspRenderedDosageInstruction named rendered 0..1 and
    DspConfidenceScore named confidence 0..1 and
    DspTranscriptTurnRefs named turnRefs 0..1

Profile: DspServiceRequestLab
Parent: USCoreServiceRequestProfile
Id: DspServiceRequestLab
Title: "DSP ServiceRequest (lab)"
* extension contains DspAbbreviation named abbrev 0..1

Profile: DspServiceRequestImaging
Parent: ServiceRequest
Id: DspServiceRequestImaging
Title: "DSP ServiceRequest (imaging)"
* extension contains
    DspImagingModality named modality 0..1 and
    DspImagingViews named views 0..* and
    DspImagingContrast named contrast 0..1
* bodySite.extension contains DspBodysiteLaterality named laterality 0..1

Profile: DspServiceRequestProcedure
Parent: ServiceRequest
Id: DspServiceRequestProcedure
Title: "DSP ServiceRequest (procedure)"
* extension contains DspProcedureDevices named devices 0..*

Profile: DspServiceRequestReferral
Parent: ServiceRequest
Id: DspServiceRequestReferral
Title: "DSP ServiceRequest (referral)"
* performerType 0..1

Profile: DspServiceRequestFollowUp
Parent: ServiceRequest
Id: DspServiceRequestFollowUp
Title: "DSP ServiceRequest (follow-up)"
* extension contains
    DspReturnIn named returnIn 0..1 and
    DspPrn named prn 0..1

Profile: DspNutritionOrder
Parent: NutritionOrder
Id: DspNutritionOrder
Title: "DSP NutritionOrder"

Profile: DspImmunizationRecommendation
Parent: ImmunizationRecommendation
Id: DspImmunizationRecommendation
Title: "DSP ImmunizationRecommendation (no administration evidence)"

Profile: DspImmunization
Parent: USCoreImmunizationProfile
Id: DspImmunization
Title: "DSP Immunization (administration evidence present)"

Profile: DspDeviceRequest
Parent: DeviceRequest
Id: DspDeviceRequest
Title: "DSP DeviceRequest"

Profile: DspServiceRequestTherapy
Parent: ServiceRequest
Id: DspServiceRequestTherapy
Title: "DSP ServiceRequest (therapy)"

Profile: DspCarePlan
Parent: CarePlan
Id: DspCarePlan
Title: "DSP CarePlan (activity aggregator)"
* activity 1..*

Profile: DspServiceRequestStudy
Parent: ServiceRequest
Id: DspServiceRequestStudy
Title: "DSP ServiceRequest (study — diagnostic intent)"

Profile: DspResearchSubject
Parent: ResearchSubject
Id: DspResearchSubject
Title: "DSP ResearchSubject (study — research enrollment)"

Profile: DspProvenance
Parent: Provenance
Id: DspProvenance
Title: "DSP Provenance (R4 — required per ingest)"
* target 1..*
* entity 1..*
* entity.what only Reference(DspDocumentReferenceTranscript)

Profile: DspMediaRecording
Parent: Media
Id: DspMediaRecording
Title: "DSP Media (audio/video)"
* extension contains DspRecordingSource named source 0..1
* content.url 1..1

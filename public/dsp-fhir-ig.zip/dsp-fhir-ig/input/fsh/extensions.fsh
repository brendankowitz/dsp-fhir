// DSP-FHIR extensions. Canonical root: https://dsp-fhir.org/StructureDefinition/

Extension: DspConfidenceScore
Id: dsp-confidence-score
Title: "DSP confidence score"
Description: "0..1 model confidence for a resource or element derived from a Dragon Copilot transcript."
* ^context.type = #element
* ^context.expression = "Element"
* value[x] only decimal
* valueDecimal 1..1
* valueDecimal ^minValueDecimal = 0.0
* valueDecimal ^maxValueDecimal = 1.0

Extension: DspTranscriptTurnRefs
Id: dsp-transcript-turn-refs
Title: "Transcript turn references"
Description: "Turn indices within a DocumentReference transcript that justify this resource/element. Immutable within a transcript versionId (R1)."
* ^context.type = #element
* ^context.expression = "Element"
* extension contains turn 1..* and transcript 0..1
* extension[turn].value[x] only integer
* extension[transcript].value[x] only Reference(DocumentReference)

Extension: DspSpokenForms
Id: dsp-spoken-forms
Title: "Spoken forms"
Description: "Verbatim phrases captured by Dragon Copilot (pre-normalisation)."
* ^context.type = #element
* ^context.expression = "Element"
* value[x] only string

Extension: DspPayloadVersion
Id: dsp-payload-version
Title: "DSP payload version"
* ^context[0].type = #element
* ^context[0].expression = "Encounter"
* ^context[+].type = #element
* ^context[=].expression = "Bundle"
* extension contains major 1..1 and minor 1..1 and revision 0..1 and quality 0..1 and metadata 0..*
* extension[major].value[x] only integer
* extension[minor].value[x] only integer
* extension[revision].value[x] only integer
* extension[quality].value[x] only code
* extension[quality].valueCode from DspPayloadQuality (required)
* extension[metadata].extension contains key 1..1 and value 1..1
* extension[metadata].extension[key].value[x] only string
* extension[metadata].extension[value].value[x] only string

Extension: DspExternalCallbackUrl
Id: dsp-external-callback-url
Title: "External callback URL"
* ^context.type = #element
* ^context.expression = "Encounter"
* value[x] only url

Extension: DspRecordingLocale
Id: dsp-recording-locale
Title: "Recording locale"
* ^context.type = #element
* ^context.expression = "Encounter"
* value[x] only code

Extension: DspTimezone
Id: dsp-timezone
Title: "Encounter timezone (IANA)"
* ^context.type = #element
* ^context.expression = "Encounter"
* value[x] only string

Extension: DspImagingModality
Id: dsp-imaging-modality
Title: "Imaging modality"
* ^context.type = #element
* ^context.expression = "ServiceRequest"
* value[x] only CodeableConcept

Extension: DspImagingViews
Id: dsp-imaging-views
Title: "Imaging views"
* ^context.type = #element
* ^context.expression = "ServiceRequest"
* value[x] only string

Extension: DspImagingContrast
Id: dsp-imaging-contrast
Title: "Imaging contrast"
* ^context.type = #element
* ^context.expression = "ServiceRequest"
* value[x] only code

Extension: DspBodysiteLaterality
Id: dsp-bodysite-laterality
Title: "Body site laterality"
* ^context.type = #element
* ^context.expression = "CodeableConcept"
* value[x] only code

Extension: DspReturnIn
Id: dsp-return-in
Title: "Return-in duration (follow-up)"
* ^context.type = #element
* ^context.expression = "ServiceRequest"
* value[x] only Duration

Extension: DspApproximation
Id: dsp-approximation
Title: "Approximation marker"
* ^context.type = #element
* ^context.expression = "Duration"
* value[x] only boolean

Extension: DspPrn
Id: dsp-prn
Title: "PRN (as needed)"
* ^context.type = #element
* ^context.expression = "ServiceRequest"
* value[x] only boolean

Extension: DspProcedureDevices
Id: dsp-procedure-devices
Title: "Procedure devices (free-text)"
* ^context.type = #element
* ^context.expression = "ServiceRequest"
* value[x] only string

Extension: DspAbbreviation
Id: dsp-abbreviation
Title: "Lab/order abbreviation"
* ^context.type = #element
* ^context.expression = "ServiceRequest"
* value[x] only string

Extension: DspRenderedDosageInstruction
Id: dsp-rendered-dosage-instruction
Title: "Rendered dosage instruction (R5 cross-version)"
* ^context.type = #element
* ^context.expression = "MedicationRequest"
* value[x] only string

Extension: DspConceptId
Id: dsp-concept-id
Title: "Dragon internal concept identifier"
* ^context.type = #element
* ^context.expression = "CodeableConcept"
* value[x] only string

Extension: DspAssertionCategory
Id: dsp-assertion-category
Title: "Clinical assertion category"
* ^context.type = #element
* ^context.expression = "Condition"
* value[x] only code
* valueCode from DspAssertionCategory (required)

Extension: DspLinkageConfidence
Id: dsp-linkage-confidence
Title: "Linkage confidence"
* ^context.type = #element
* ^context.expression = "Element"
* extension contains score 1..1 and level 0..1
* extension[score].value[x] only decimal
* extension[level].value[x] only code

Extension: DspRecordingSource
Id: dsp-recording-source
Title: "Recording source"
* ^context.type = #element
* ^context.expression = "Media"
* value[x] only code
* valueCode from DspRecordingSource (required)

Extension: DspResourceSource
Id: dsp-resource-source
Title: "DSP resource source"
* ^context.type = #element
* ^context.expression = "Resource"
* value[x] only code
* valueCode from DspResourceSource (required)

Extension: DspSpeakerCount
Id: dsp-speaker-count
Title: "Speaker count"
* ^context.type = #element
* ^context.expression = "DocumentReference"
* value[x] only positiveInt

Extension: DspPayloadVersionsAdvert
Id: dsp-payload-versions
Title: "DSP payload versions advertised"
Description: "CapabilityStatement.rest-level extension declaring accepted and emitted payload-version values (R3)."
* ^context.type = #element
* ^context.expression = "CapabilityStatement.rest"
* extension contains accepted 1..* and emitted 1..*
* extension[accepted].value[x] only string
* extension[emitted].value[x] only string

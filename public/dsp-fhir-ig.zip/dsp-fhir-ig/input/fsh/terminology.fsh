CodeSystem: DspPayloadQualityCS
Id: dsp-payload-quality
Title: "DSP payload quality"
* ^caseSensitive = true
* #complete "Complete"
* #partial "Partial"
* #unavailable "Unavailable"
* #pending "Pending"
* #error "Error"

ValueSet: DspPayloadQuality
Id: dsp-payload-quality-vs
Title: "DSP payload quality"
* include codes from system DspPayloadQualityCS

CodeSystem: DspAssertionCategoryCS
Id: dsp-assertion-category
Title: "DSP assertion category"
* ^caseSensitive = true
* #asserted "Asserted"
* #denied "Denied / Negated"
* #unknown "Unknown"
* #suspected "Suspected"
* #history "Historical"

ValueSet: DspAssertionCategory
Id: dsp-assertion-category-vs
Title: "DSP assertion category"
* include codes from system DspAssertionCategoryCS

CodeSystem: DspRecordingSourceCS
Id: dsp-recording-source
Title: "DSP recording source"
* ^caseSensitive = true
* #DAXAPP "Dragon Copilot mobile app"
* #"DAXKIT.haiku" "DAX Kit via Epic Haiku"
* #"DAXKIT.teams" "DAX Kit via Microsoft Teams"
* #PMM "Dragon Professional / Medical Mobile"

ValueSet: DspRecordingSource
Id: dsp-recording-source-vs
Title: "DSP recording source"
* include codes from system DspRecordingSourceCS

CodeSystem: DspResourceSourceCS
Id: dsp-resource-source
Title: "DSP resource source"
* ^caseSensitive = true
* #dragon_copilot "Dragon Copilot"
* #ehr_integration "EHR integration"
* #extension "Extension / third-party"

ValueSet: DspResourceSource
Id: dsp-resource-source-vs
Title: "DSP resource source"
* include codes from system DspResourceSourceCS

CodeSystem: DspOrderCategoryCS
Id: dsp-order-category
Title: "DSP order category"
* ^caseSensitive = true
* #follow-up "Follow-up"
* #referral "Referral"
* #therapy "Therapy"
* #activity "Activity"
* #study "Study"

ValueSet: DspOrderCategory
Id: dsp-order-category-vs
Title: "DSP order category"
* include codes from system DspOrderCategoryCS

ValueSet: DspDocumentSection
Id: dsp-document-section-vs
Title: "DSP document section"
* LOINC#51855-5 "Patient note"
* LOINC#8648-8 "Hospital course Narrative"
* LOINC#10164-2 "History of Present illness Narrative"
* LOINC#10187-3 "Review of systems Narrative"
* LOINC#11348-0 "History of Past illness Narrative"
* LOINC#10160-0 "History of Medication use Narrative"
* LOINC#48765-2 "Allergies and adverse reactions Document"
* LOINC#29545-1 "Physical findings Narrative"
* LOINC#51847-2 "Evaluation + Plan note"
* LOINC#18776-5 "Plan of care note"

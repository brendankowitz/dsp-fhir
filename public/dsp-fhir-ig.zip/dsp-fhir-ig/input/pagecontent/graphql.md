# Canonical `$graphql` query

The IG publishes **one canonical GraphQL query** as the DSP read contract.
`DSP-Core` and `DSP-Read` servers SHALL answer it correctly; clients SHALL NOT
derive their own equivalent for conformance-critical reads.

See [`input/examples/graphql-encounter-query.txt`](../input/examples/graphql-encounter-query.txt).

# DSP ↔ FHIR mappings

Full side-by-side mappings: <https://brendankowitz.github.io/dsp-fhir/mapping>.

| DSP | FHIR target | Profile |
|---|---|---|
| `document_section` | `Composition.section` | `DspComposition` |
| `condition` | `Condition` | `DspCondition` |
| `order.medication` | `MedicationRequest` | `DspMedicationRequest` |
| `order.procedure` | `ServiceRequest` (procedure) | `DspServiceRequestProcedure` |
| `order.lab` | `ServiceRequest` (laboratory) | `DspServiceRequestLab` |
| `order.imaging` | `ServiceRequest` (imaging) | `DspServiceRequestImaging` |
| `order.follow-up` | `ServiceRequest` (follow-up) | `DspServiceRequestFollowUp` |
| `order.referral` | `ServiceRequest` (referral) | `DspServiceRequestReferral` |
| `order.dietary` | `NutritionOrder` | `DspNutritionOrder` |
| `order.immunization` (intent) | `ImmunizationRecommendation` | `DspImmunizationRecommendation` |
| `order.immunization` (administered) | `Immunization` | `DspImmunization` |
| `order.device` | `DeviceRequest` | `DspDeviceRequest` |
| `order.therapy` | `ServiceRequest` (therapy) + `Goal` | `DspServiceRequestTherapy` |
| `order.activity` | `CarePlan.activity` / `ServiceRequest` (fallback) | `DspCarePlan` |
| `order.study` (diagnostic) | `ServiceRequest` (study) | `DspServiceRequestStudy` |
| `order.study` (research) | `ResearchSubject` + `ResearchStudy` | `DspResearchSubject` |

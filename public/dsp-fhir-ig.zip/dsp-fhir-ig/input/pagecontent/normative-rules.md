# Normative rules (R1–R4)

## R1 · Transcript turn-index stability
Turn indices **SHALL** be immutable within a `DocumentReference.meta.versionId`.
Re-transcription **SHALL** create a new `DocumentReference` version.

## R2 · Recording content binding
Recordings **SHALL** be served from a `Binary` endpoint on the issuing server,
under SMART on FHIR scopes for the patient compartment.

## R3 · Payload-version negotiation
Servers **SHALL** advertise accepted and emitted DSP `payload-version` values in
`CapabilityStatement` via the `dsp-payload-versions` extension. No silent upgrades.

## R4 · Provenance per ingest
Every ingest transaction **SHALL** produce at least one `Provenance` targeting
every resource created/updated, with `entity` referencing the source transcript
`DocumentReference`.

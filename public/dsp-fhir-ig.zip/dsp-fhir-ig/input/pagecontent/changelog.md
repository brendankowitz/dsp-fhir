# Changelog

## 0.1.0-draft — initial draft

- Profiles for all 15 DSP resource types.
- Extensions for DSP-specific semantics.
- Value sets / code systems.
- CapabilityStatement (DSP-Core level).
- OperationDefinition: `$ground`.
- DSP logical models (envelope + per content_type).
- FML skeletons: condition, medication order.
- Normative rules R1–R4.
- Worked example Bundle + illustrative DSP condition input.

# Background — DSP 1.0

DSP is Microsoft's JSON payload emitted by Dragon Copilot after an ambient
clinical encounter:

- **Encounter context** — participants, timezone, locale, payload version, callback URL, quality flag.
- **Transcript** — speaker-turned utterances with monotonically increasing, stable turn indices.
- **Recording** (optional) — audio/video via signed URL.
- **Clinical resources** grouped by `content_type`:
  - `document_section` — narrative sections (HPI, ROS, A&P, Plan, Overview, …)
  - `condition` — problems/diagnoses, asserted or denied
  - `order.{type}` — medication / procedure / lab / imaging / dietary /
    immunization / study / therapy / activity / device / follow-up / referral

Every clinical resource carries `transcript_turn_refs`, a `confidence`
score, and `spoken_forms`. Grounding (traceability back to transcript turns)
is DSP's central promise.

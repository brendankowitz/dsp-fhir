# Design decisions

## R4 vs R5 vs R6

**Decision: R4 (4.0.1) core, R5 cross-version extensions for specific gaps.**

| Option | Pros | Cons |
|---|---|---|
| **R4** | US Core 7 ecosystem; widespread deployment; Bulk Data/SMART stable. | Missing `MedicationRequest.renderedDosageInstruction`, `DeviceUsage`, newer subscription/graphql semantics. |
| **R5** | Native fixes for most DSP-relevant gaps. | US Core lagging; partner servers rarely R5 yet. |
| **R6** | Even better alignment. | Not normative; not deployable. |

## `$graphql` as the read contract

DSP is a graph. Published canonical query = single versioned read contract
for all partners. See `graphql.html` and `operations.html`.

## FML + logical models

DSP gets a FHIR logical model (`DspPayload` / `DspResource` / per-type
submodels). FML maps DSP resources to FHIR profiles. Partners can execute via
`StructureMap/$transform` instead of writing bespoke converters. See `fml-strategy.html`.

## One custom operation, not ten

Every custom-op candidate was checked against base FHIR + major IGs (US Core,
Bulk Data, IPS, SMART, Subscriptions R5 Backport, CPG). All but one resolved
to an existing op. Survivor: `$ground` — transcript turn-join.

## Immunization / Study / Activity disambiguation

DSP collapses FHIR distinctions; the IG picks routing rules:

- `IMMUNIZATION_ORDER` + administration evidence → `Immunization`; else
  `ImmunizationRecommendation`.
- `STUDY_ORDER` + clinical-trial registry id → `ResearchSubject` +
  `ResearchStudy`; else `ServiceRequest(category=study)`.
- `ACTIVITY_ORDER` → `CarePlan.activity`; fall back to standalone
  `ServiceRequest(category=activity)` when per-activity provenance matters.

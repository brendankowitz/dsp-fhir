# Operations audit (summary)

| Need | Operation | Source |
|---|---|---|
| Whole-encounter read | `Encounter/$everything` | Core FHIR |
| Canonical read contract | `$graphql` + published query | Core FHIR |
| Server capability declaration | `CapabilityStatement` | Core FHIR |
| Validate pre-commit | `$validate` | Core FHIR |
| Generate signed notes | `Composition/$document` | Core FHIR |
| Find latest note by type | `$docref` | US Core |
| Cross-encounter bulk | `Patient/$export?_since=` | Bulk Data |
| Terminology expand/lookup | `$expand`, `$lookup` | Core FHIR |
| Apply order-set plan | `PlanDefinition/$apply` | CPG |
| Patient matching | `Patient/$match` | Core FHIR |
| **DSP ↔ FHIR transform** | **`StructureMap/$transform`** + published maps | **Core FHIR + this IG** |
| **Turn-join grounding** | **`$ground`** (custom) | **DSP-FHIR** |

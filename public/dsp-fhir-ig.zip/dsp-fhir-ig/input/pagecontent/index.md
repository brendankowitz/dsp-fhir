# DSP-FHIR IG (draft 0.1.0-draft)

> Draft IG authored outside HL7 to explore how
> [Dragon Standard Payload (DSP) 1.0](https://learn.microsoft.com/en-us/industry/healthcare/dragon-copilot/sdk/partner-apis/dragon-data-exchange/dragon-standard-payload/)
> maps onto HL7 FHIR. Not affiliated with Microsoft/Nuance; not balloted.

## What's in this IG

- **DSP logical models** (kind=logical StructureDefinitions) describing the DSP
  JSON shape in FHIR-native terms, enabling `$validate` against incoming DSP
  payloads before transformation.
- **Profiles** on R4 resources for every DSP content_type (15 types incl. 10 order subtypes).
- **Extensions** for DSP semantics with no natural FHIR home (turn refs,
  confidence, payload-version, assertion category, spoken forms, imaging/follow-up/etc.).
- **Value sets / code systems** for DSP enumerations.
- **FML / StructureMap** skeletons: executable DSP → FHIR mappings and FHIR → DSP
  reconstruction maps for every resource mapping; see `fml-strategy.html`.
- **CapabilityStatement** declaring the four conformance levels.
- **One custom OperationDefinition:** `$ground` (turn-join).
- **Four normative rules** (R1–R4).

## Why R4

R4 has the US Core 7 ecosystem and widespread deployment. R5 xver extensions
fill the specific gaps (renderedDosageInstruction, DeviceUsage). See
`design-decisions.html`.

## Why `$graphql`

DSP is a graph. A canonical query published by the IG gives partners one
versioned read contract instead of N bespoke `_include` queries.

# FML / StructureMap strategy

## Why FML at all

FHIR Mapping Language (FML) — compiled to `StructureMap` resources and executed
via `StructureMap/$transform` — gives DSP-FHIR three things that prose mappings
on a website cannot:

1. **Executable.** Partners POST a DSP payload to `$transform` and receive a
   profile-valid FHIR Bundle. The mapping logic lives on a server, not in each
   partner's codebase.
2. **Machine-auditable.** FML is both human-readable and deterministically
   compilable; diffs between IG versions are reviewable.
3. **Publishable as artifacts.** StructureMaps live alongside profiles in the
   IG package, versioned together.

Precedent: [v2-to-FHIR](https://build.fhir.org/ig/HL7/v2-to-fhir/) and
[CDA-on-FHIR](http://hl7.org/fhir/us/ccda/) publish StructureMaps for the same
class of problem (non-FHIR source → FHIR).

## What FML is not good at

- **Routing decisions.** "If `administered_at` present → `Immunization`,
  else → `ImmunizationRecommendation`." Expressible via `where` clauses,
  but the conditional groups balloon. For DSP's split cases (immunization /
  study / activity) the IG documents the routing rule and expects producers or
  a thin pre-processor to split before `$transform`.
- **Stateful semantics.** R1 (turn-index stability across re-transcription
  versions) is controller logic, not mapping. StructureMap is deliberately pure.
- **Provenance generation.** FML can emit Provenance entries, but threading
  the source transcript through every target resource is awkward. The IG
  recommends generating R4 Provenance outside the map.

## Phasing

| Phase | Scope | Status in this draft |
|---|---|---|
| **1** | DSP logical models (envelope + per content_type) | ✓ included |
| **2** | FML for deterministic and routing-split DSP → FHIR maps | ✓ included for all resource mappings |
| **3** | FML for FHIR → DSP reconstruction maps | ✓ included for all resource mappings |
| **4** | Stateful grounding / provenance orchestration | controller logic, not FML |

## What ships in this draft

- `input/fsh/logical-models.fsh` — DSP envelope, context, transcript, recording, resource and per-type logical models.
- `input/fsh/profiles.fsh` — all DSP-FHIR resource profiles.
- `input/profiles/README.md` — human-readable profile catalog.
- `input/maps/dsp-to-fhir/` — all forward DSP → FHIR FML skeletons.
- `input/maps/fhir-to-dsp/` — all reverse FHIR → DSP reconstruction skeletons.
- `input/maps/README.md` — execution notes for matchbox / HAPI.

## Executing

```bash
# matchbox (reference):
docker run -p 8080:8080 eu.gcr.io/fhir-ch/matchbox:latest
# Upload logical models + StructureMaps, then:
curl -X POST http://localhost:8080/fhir/StructureMap/\$transform?source=https://dsp-fhir.org/StructureMap/DspConditionToCondition \
  -H 'Content-Type: application/fhir+json' \
  --data @my-dsp-condition.json
```

# FML / StructureMap sources

These are reference FHIR Mapping Language skeletons for the **DSP → FHIR write
projection**. The same source strings power the companion website's mapping
tabs, so the downloadable IG package and site stay in lockstep.

The reverse direction (**FHIR → DSP**) is published as a canonical FHIR
`$graphql` query plus a deterministic reconstruction adapter on each
[mapping page](https://brendankowitz.github.io/dsp-fhir/mapping). FML inverse
maps are not shipped because GraphQL + the IG's `dsp-*` extension landings
already provide a no-data-loss read path.

## Files

| File | Direction | DSP area |
|---|---|---|
| `dsp-to-fhir/DspConditionToCondition.map` | DSP → FHIR | `condition` |
| `dsp-to-fhir/DspMedicationOrderToMedicationRequest.map` | DSP → FHIR | `medication` |
| `dsp-to-fhir/DspLabOrderToServiceRequest.map` | DSP → FHIR | `lab` |
| `dsp-to-fhir/DspImagingOrderToServiceRequest.map` | DSP → FHIR | `imaging` |
| `dsp-to-fhir/DspProcedureOrderToServiceRequest.map` | DSP → FHIR | `procedure` |
| `dsp-to-fhir/DspReferralOrderToServiceRequest.map` | DSP → FHIR | `referral` |
| `dsp-to-fhir/DspFollowUpOrderToServiceRequest.map` | DSP → FHIR | `follow-up` |
| `dsp-to-fhir/DspDocumentSectionToCompositionSection.map` | DSP → FHIR | `document-section` |
| `dsp-to-fhir/DspDietaryOrderToNutritionOrder.map` | DSP → FHIR | `dietary` |
| `dsp-to-fhir/DspImmunizationOrderToImmunization.map` | DSP → FHIR | `immunization` |
| `dsp-to-fhir/DspDeviceOrderToDeviceRequest.map` | DSP → FHIR | `device` |
| `dsp-to-fhir/DspTherapyOrderToServiceRequest.map` | DSP → FHIR | `therapy` |
| `dsp-to-fhir/DspActivityOrderToCarePlan.map` | DSP → FHIR | `activity` |
| `dsp-to-fhir/DspStudyOrderToServiceRequest.map` | DSP → FHIR | `study` |

## Notes

- **Routing-split mappings** (immunization, study, activity) include the primary
  branch plus comments for alternate branches. Producers should split upstream
  before invoking a map when source data can route to multiple FHIR resource
  types.
- **Grounding state (R1)** is controller logic, not mapping. StructureMap is
  deliberately pure.

## Running against a DSP payload

```bash
# With matchbox (Docker):
docker run -p 8080:8080 eu.gcr.io/fhir-ch/matchbox:latest
# PUT each StructureDefinition + StructureMap, then:
curl -X POST http://localhost:8080/fhir/StructureMap/\$transform \
  -H 'Content-Type: application/fhir+json' \
  --data @my-dsp-condition.json
```

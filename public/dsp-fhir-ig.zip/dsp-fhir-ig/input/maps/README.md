# FML / StructureMap sources

These are **skeleton** FHIR Mapping Language files demonstrating the DSP →
FHIR transformation approach. They are not complete coverage of all 15 DSP
resource types — see `../pagecontent/fml-strategy.md` for the phasing.

## Files

| File | Direction | Coverage | Notes |
|---|---|---|---|
| `DspConditionToCondition.map` | DSP → FHIR | Complete | Demonstrates assertion-category routing to `verificationStatus`, turn-ref / confidence / spoken-forms extension generation. |
| `DspMedicationOrderToMedicationRequest.map` | DSP → FHIR | Complete | RxNorm-code resolution, rendered-dosage-instruction carrying via R5 xver extension + literal `dosageInstruction.text`. |

## What's intentionally **not** here yet

- **Routing-split mappings** (immunization → Immunization vs
  ImmunizationRecommendation; study → ServiceRequest vs ResearchSubject;
  activity → CarePlan.activity vs standalone ServiceRequest). FML can express
  these with `where` clauses on input fields but the condition logic is
  awkward enough that Phase-3 implementations are expected to split upstream
  before invoking the map.
- **Reverse FHIR → DSP maps.** Phase 4.
- **Grounding state (R1).** Cross-version turn-index management is controller
  logic, not mapping. StructureMap is deliberately pure.

## Running against a DSP payload

```bash
# With matchbox (Docker):
docker run -p 8080:8080 eu.gcr.io/fhir-ch/matchbox:latest
# PUT each StructureDefinition + StructureMap, then:
curl -X POST http://localhost:8080/fhir/StructureMap/\$transform \
  -H 'Content-Type: application/fhir+json' \
  --data @my-dsp-condition.json
```
